/*
 * Thread.hpp
 *
 *  Created on: 2018-3-20
 *      Author: root
 */

#ifndef INCLUDE_COMMON_THREAD_HPP_H_
#define INCLUDE_COMMON_THREAD_HPP_H_

#include <pthread.h>
#include <string>

namespace common
{
static void* ThreadBody(void *args);

class CThread
{
protected:
	CThread(const std::string& threadName)
	: m_bLooping(false)
	, m_threadName(threadName)
	{

	}

	virtual ~CThread() {};

public:
	virtual void Run() = 0;
	void SetLoopingState(bool state)
	{
		m_bLooping = state;
	}

public:
	bool CreateThread()
	{
		return 0 == pthread_create(&m_threadID, NULL, ThreadBody, this);
	}

	bool Join()
	{
		return 0 == pthread_join(m_threadID, NULL);
	}

protected:
	bool 			m_bLooping;

private:
	std::string m_threadName;
	pthread_t   m_threadID;
};

void* ThreadBody(void *args)
{
	CThread* thread = static_cast<CThread*>(args);
	if(NULL != thread)
	{
		thread->SetLoopingState(true);
		thread->Run();
	}

	return NULL;
}
}  // namespace common

#endif  // INCLUDE_COMMON_THREAD_HPP_H_
