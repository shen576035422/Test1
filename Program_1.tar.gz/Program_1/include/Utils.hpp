/*
 * Utils.hpp
 *
 *  Created on: 2018-3-20
 *      Author: root
 */

#ifndef INCLUDE_COMMON_UTILS_H_
#define INCLUDE_COMMON_UTILS_H_

namespace common
{

char GetRandomData(int index)
{
	char letter = '0';
	if(index >= 0 && index < 10)
	{
		letter = '0' + index;
	}
	else if(index >= 10 && index < 36)
	{
		letter = 'A' + index - 10;
	}
	else if(index >= 36 && index < 62)
	{
		letter = 'a' + index - 36;
	}
	else
	{
		assert(0); //should never run here
	}

	return letter;
}

void GenerateRandomLetters(char* randomLetter)
{
	const size_t LOOP_COUNT = 3;
	const size_t TOTAL_RANDOM_LETTER_NUM = 62;
	for(size_t i = 0; i < LOOP_COUNT; ++i)
	{
		int randomNum = rand();
		char *ptr = (char *)(&randomNum);
		for(size_t j = 0; j < sizeof(int); ++j)
		{
			int index = (ptr[j] & 0xFF) % TOTAL_RANDOM_LETTER_NUM;
			randomLetter[i * sizeof(int) + j] = GetRandomData(index);
		}
	}
}

}  // namespace common

#endif  // INCLUDE_COMMON_UTILS_H_
