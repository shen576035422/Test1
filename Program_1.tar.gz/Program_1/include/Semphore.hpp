/*
 * Semphore.hpp
 *
 *  Created on: 2018-3-19
 *      Author: root
 */

#ifndef INCLUDE_COMMON_SEMPHORE_HPP_
#define INCLUDE_COMMON_SEMPHORE_HPP_

#include <assert.h>
#include <semaphore.h>

namespace common
{

class CSemphore
{
public:
	explicit CSemphore(int initValue)
	{
		int ret = sem_init(&m_sem, 0, initValue);
		assert(0 == ret);

	}
	~CSemphore()
	{
		int ret = sem_destroy(&m_sem);
		assert(0 == ret);
	}

public:
	void Pend()
	{
		sem_wait(&m_sem);
	}
	void Post()
	{
		sem_post(&m_sem);
	}

private:
	//no copyable
	CSemphore(const CSemphore&);
	CSemphore& operator=(const CSemphore&);

private:
	sem_t m_sem;
};

}  // namespace common

#endif  // INCLUDE_COMMON_SEMPHORE_HPP_
