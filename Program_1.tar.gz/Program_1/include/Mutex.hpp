/*
 * Mutex.hpp
 *
 *  Created on: 2018-3-19
 *      Author: root
 */

#ifndef INCLUDE_COMMON_MUTEX_HPP_
#define INCLUDE_COMMON_MUTEX_HPP_

#include <assert.h>
#include <pthread.h>

namespace common
{

class CMutex
{
public:
		CMutex()
		{
			int ret = pthread_mutex_init(&m_mutex, NULL);
			assert(0 == ret);
		}
		~CMutex()
		{
			int ret = pthread_mutex_destroy(&m_mutex);
			assert(0 == ret);
		}

public:
		void Enter()
		{
			pthread_mutex_lock(&m_mutex);
		}
		void Leave()
		{
			pthread_mutex_unlock(&m_mutex);
		}

private:
		//no copyable
		CMutex(const CMutex&);
		CMutex& operator=(const CMutex&);

private:
		pthread_mutex_t m_mutex;
};

}  // namespace common

#endif  // INCLUDE_MUTEX_HPP_
