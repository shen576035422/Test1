/*
 * Define.h
 *
 *  Created on: 2018-3-20
 *      Author: root
 */

#ifndef INCLUDE_COMMON_DEFINE_H_
#define INCLUDE_COMMON_DEFINE_H_

namespace common
{
typedef char* Productor;

}  // namespace common

#endif  // INCLUDE_COMMON_DEFINE_H_
