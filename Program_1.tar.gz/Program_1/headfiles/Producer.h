/*
 * Producer.h
 *
 *  Created on: 2018-3-19
 *      Author: root
 */

#ifndef HEADFILES_PRODUCER_H_
#define HEADFILES_PRODUCER_H_

#include "Define.h"
#include "Thread.hpp"

class CProducer : public common::CThread
{
public:
	CProducer();
	~CProducer();

public:
	bool StartProduce();
	bool StopProduce();
	bool Wait();

private:
	void Run();
	common::Productor MakeProductor();

private:
	int m_count;
};

#endif  // HEADFILES_PRODUCER_H_
