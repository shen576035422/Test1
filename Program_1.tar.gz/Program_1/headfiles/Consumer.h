/*
 * Consumer.h
 *
 *  Created on: 2018-3-20
 *      Author: root
 */

#ifndef HEADFILES_CONMSUMER_H_
#define HEADFILES_CONMSUMER_H_

#include "Thread.hpp"

class CConsumer : public common::CThread
{
public:
	CConsumer();
	~CConsumer();

public:
	bool StartConsume();
	bool StopConsume();
	bool Wait();

private:
	void Run();

private:
	int m_count;
};

#endif  // HEADFILES_CONMSUMER_H_
