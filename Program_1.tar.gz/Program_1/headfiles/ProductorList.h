/*
 * ProductorList.h
 *
 *  Created on: 2018-3-19
 *      Author: root
 */

#ifndef HEADFILES_PRODUCTOR_LIST_H_
#define HEADFILES_PRODUCTOR_LIST_H_

#include <list>
#include "Define.h"
#include "Mutex.hpp"
#include "Semphore.hpp"

class CProductorList
{
public:
	static CProductorList* GetInstance();
	void PushProductor(const common::Productor& productor);
	void PopProductor(common::Productor& productor);

private:
	static void Destroy();

private:
	//for singleton
	CProductorList();
	~CProductorList();
	CProductorList(const CProductorList&);
	CProductorList& operator=(const CProductorList&);

private:
	static common::CMutex m_mutex;
	static CProductorList* m_inst;

private:
	common::CSemphore m_sem;
	common::CMutex m_msgMutex;
	std::list<common::Productor> m_productorList;
};

#define g_ProductorList (*CProductorList::GetInstance())

#endif  // HEADFILES_PRODUCTOR_LIST_H_
