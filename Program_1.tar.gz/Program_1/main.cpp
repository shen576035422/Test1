/*
 * main.cpp
 *
 *  Created on: 2018-3-20
 *      Author: root
 */
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include "Producer.h"
#include "Consumer.h"

CConsumer g_consumer;
CProducer g_producer;

void AlarmHandler(int signum)
{
	g_producer.StopProduce();
	g_consumer.StopConsume();
}

int main(int argc, char* argv[])
{
	if(argc != 2 || NULL == argv[1])
	{
		std::cout<<"Usgae: "<<argv[0]<<" <seconds>\n";
		exit(-1);	
	}
	int waitTime = atoi(argv[1]);
	signal(SIGALRM, AlarmHandler);
	alarm(waitTime);

	g_producer.StartProduce();
	g_consumer.StartConsume();
	g_producer.Wait();
	g_consumer.Wait();

	return 0;
}
