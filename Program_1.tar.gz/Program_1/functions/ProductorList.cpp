/*
 * ProductorList.cpp
 *
 *  Created on: 2018-3-19
 *      Author: root
 */
#include "ProductorList.h"
#include <stdlib.h>

common::CMutex  CProductorList::m_mutex;
CProductorList* CProductorList::m_inst = NULL;

CProductorList* CProductorList::GetInstance()
{
	if(NULL == m_inst)
	{
		m_mutex.Enter();
		if(NULL == m_inst)
		{
			m_inst = new CProductorList;
			atexit(Destroy);
		}
		m_mutex.Leave();
	}

	return m_inst;
}

CProductorList::CProductorList() : m_sem(0)
{

}
CProductorList::~CProductorList()
{
	std::list<common::Productor>::iterator itr = m_productorList.begin();
	for( ; itr != m_productorList.end(); ++itr)
	{
		if(NULL != *itr)
		{
			delete *itr;
		}
	}
}

void CProductorList::Destroy()
{
	if(NULL != m_inst)
	{
		delete m_inst;
		m_inst = NULL;
	}
}

void CProductorList::PushProductor(const common::Productor& productor)
{
	m_msgMutex.Enter();
	m_productorList.push_back(productor);
	m_msgMutex.Leave();

	m_sem.Post();
}

void CProductorList::PopProductor(common::Productor& productor)
{
	m_sem.Pend();

	m_msgMutex.Enter();
	productor = m_productorList.front();
	m_productorList.pop_front();
	m_msgMutex.Leave();
}
