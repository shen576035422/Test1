/*
 * Producer.cpp
 *
 *  Created on: 2018-3-19
 *      Author: root
 */

#include "Producer.h"
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <iostream>
#include "ProductorList.h"
#include "Utils.hpp"

CProducer::CProducer()
: CThread("Producer")
, m_count(0)
{

}

CProducer::~CProducer()
{
	std::cout<<"Total Produce count: "<<m_count<<std::endl;
}

bool CProducer::StartProduce()
{
	return CreateThread();
}

bool CProducer::StopProduce()
{
	m_bLooping = false;
	return true;
}

bool CProducer::Wait()
{
	return Join();
}

void CProducer::Run()
{
	srand(time(NULL));
	while(m_bLooping)
	{
		common::Productor producotr = MakeProductor();
		g_ProductorList.PushProductor(producotr);
		++m_count;
	}
}

common::Productor CProducer::MakeProductor()
{
	const size_t LETTER_NUM = 13;
	common::Productor randomLetter = new char[LETTER_NUM];
	memset(randomLetter, 0, LETTER_NUM);

	common::GenerateRandomLetters(randomLetter);

	return randomLetter;
}
