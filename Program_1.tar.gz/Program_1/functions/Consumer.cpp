/*
 * Consumer.cpp
 *
 *  Created on: 2018-3-20
 *      Author: root
 */
#include "Consumer.h"
#include <iostream>
#include <algorithm>
#include "Define.h"
#include "ProductorList.h"

CConsumer::CConsumer()
: CThread("Consumer")
, m_count(0)
{

}

CConsumer::~CConsumer()
{
	std::cout<<"Total Consume Num: "<<m_count<<std::endl;
}

bool CConsumer::StartConsume()
{
	return CreateThread();
}

bool CConsumer::StopConsume()
{
	m_bLooping = false;
	return true;
}
bool CConsumer::Wait()
{
	return Join();
}

void CConsumer::Run()
{
	while(m_bLooping)
	{
		common::Productor productor = NULL;
		g_ProductorList.PopProductor(productor);
		if(NULL != productor)
		{
			std::string str(productor);
			std::sort(str.begin(), str.end());
			++m_count;
			delete [] productor;
			productor = NULL;
		}
	}
}

