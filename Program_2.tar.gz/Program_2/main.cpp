/*
 * main.cpp
 *
 *  Created on: 2018-3-20
 *      Author: root
 */
#include <assert.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <algorithm>
#include <iostream>
#include <string>
#include "Utils.hpp"

bool g_bLoop = true;

void AlarmHandler(int signum)
{
	g_bLoop = false;
}

int main(int argc, char* argv[])
{
	if(argc != 2 || NULL == argv[1])
	{
		std::cout<<"Usgae: "<<argv[0]<<" <seconds>\n";
		exit(-1);	
	}
	int waitTime = atoi(argv[1]);
	
	srand(time(NULL));
	signal(SIGALRM, AlarmHandler);
	alarm(waitTime);
	const size_t LETTER_COUNT = 13;
	char randomLetter[LETTER_COUNT] = {0};
	int count = 0;
	while(g_bLoop)
	{
		common::GenerateRandomLetters(randomLetter);
		std::string ss(randomLetter);
		std::sort(ss.begin(), ss.end());
		++count;
	}
	std::cout<<"Count: "<<count<<std::endl;
	return 0;
}
